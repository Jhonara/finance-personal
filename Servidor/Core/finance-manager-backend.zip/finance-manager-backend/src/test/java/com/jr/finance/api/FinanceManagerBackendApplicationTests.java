package com.jr.finance.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinanceManagerBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
